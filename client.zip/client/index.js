import App from './components/App';

document.addEventListener('DOMContentLoaded', () => {
  const app = new App();
  app.init();
});
