import { defineConfig } from "vite";

export default defineConfig({
    build: {
        assersDir: './',
        outDir: '../dist',
        emptyOutDir: '../dist'
    }
});